package RallyEntities;

import java.util.List;

public interface RallyRepository {

	List<RallyDTO> findAll();

	RallyDTO getById(Long id);

	Long save(RallyDTO cto);

	void deleteById(Long id);

}
