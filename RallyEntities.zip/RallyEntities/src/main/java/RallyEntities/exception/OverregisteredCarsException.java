package RallyEntities.exception;

public class OverregisteredCarsException extends RuntimeException {

}
