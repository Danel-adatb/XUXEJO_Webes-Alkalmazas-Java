package RallyEntities;

import java.util.ArrayList;
import java.util.List;


public class RallyRepoMemory implements RallyRepository{
	
	private final List<RallyDTO> cars = new ArrayList<>();
	
	private int findCarById(Long id) {
		int found = -1;

		for (int i = 0; i < cars.size(); i++) {
			if (cars.get(i).getType().equals(id)) {
				found = i;
				break;
			}
		}
		return found;
	}

	@Override
	public List<RallyDTO> findAll() {
		// TODO Auto-generated method stub
		return cars;
	}

	@Override
	public RallyDTO getById(Long id) {
		return null;
	}

	@Override
	public Long save(RallyDTO cto) {
		int found = findCarById(cto.getId());

		if (found != -1) {
			RallyDTO foundCar = cars.get(found);
			foundCar.setCar(cto.getCar());
			foundCar.setDriver(cto.getDriver());
			foundCar.setType(cto.getType());
			foundCar.setRaceNumber(cto.getRaceNumber());
		} else {
			
		}
		return null;
	}

	@Override
	public void deleteById(Long id) {
		
		int found = findCarById(id);
		
		if (found != -1) {
			cars.remove(found);
		}
		
	}

}
