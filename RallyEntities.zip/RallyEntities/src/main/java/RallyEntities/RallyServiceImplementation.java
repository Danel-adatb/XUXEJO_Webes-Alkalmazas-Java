package RallyEntities;

import java.util.List;

import org.springframework.stereotype.Component;

import RallyEntities.exception.OverregisteredCarsException;

@Component
public class RallyServiceImplementation implements RallyService {

	private final int MAXIMUM_NUMBER_OF_CARS = 45;
	private final RallyRepository rallyRepository;

	public RallyServiceImplementation(RallyRepository rallyRepository) {
		super();
		this.rallyRepository = rallyRepository;
	}

	@Override
	public List<RallyDTO> findAll() {
		return rallyRepository.findAll();
	}

	@Override
	public RallyDTO getById(Long id) {
		return rallyRepository.getById(id);
	}

	@Override
	public Long save(RallyDTO cto) {
		if (rallyRepository.findAll().size() >= MAXIMUM_NUMBER_OF_CARS) {
			throw new OverregisteredCarsException();
		}
		return rallyRepository.save(cto);
	}

	@Override
	public void deleteById(Long id) {
		rallyRepository.deleteById(id);

	}

}
